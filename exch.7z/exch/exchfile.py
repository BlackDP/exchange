



class ProccessingUploadFile():

    
    def proccesing_uploaded_file():
        pass